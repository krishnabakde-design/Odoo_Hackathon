import { NavLink, useNavigate } from "react-router-dom";
import { logout, getRole } from "../utils/auth";

export default function Navbar() {
  const navigate = useNavigate();
  const role = getRole(); // "admin" or "employee"

  const navLinkClass = ({ isActive }) =>
    `px-3 py-2 rounded-md text-sm font-medium ${
      isActive
        ? "bg-blue-100 text-blue-700"
        : "text-gray-600 hover:text-blue-600 hover:bg-gray-100"
    }`;

  return (
    <nav className="bg-white shadow px-6 py-3 flex items-center justify-between">
      
      {/* Left: App Name */}
      <div
        className="text-xl font-bold text-blue-600 cursor-pointer"
        onClick={() =>
          navigate(role === "admin" ? "/admin/dashboard" : "/employee/dashboard")
        }
      >
        Dayflow
      </div>

      {/* Center: Navigation Tabs */}
      <div className="flex items-center gap-2">
        {role === "admin" && (
          <NavLink to="/admin/employees" className={navLinkClass}>
            Employees
          </NavLink>
        )}

        <NavLink
          to={role === "admin" ? "/admin/dashboard" : "/employee/attendance"}
          className={navLinkClass}
        >
          Attendance
        </NavLink>

        <NavLink
          to={role === "admin" ? "/admin/approvals" : "/employee/leaves"}
          className={navLinkClass}
        >
          Time Off
        </NavLink>
      </div>

      {/* Right: Role + Logout */}
      <div className="flex items-center gap-4">
        <span className="text-sm text-gray-500 capitalize">
          {role} panel
        </span>
        <button
          onClick={() => {
            logout();
            navigate("/login");
          }}
          className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"
        >
          Logout
        </button>
      </div>
    </nav>
  );
}
