export default function Payroll() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Employee Payroll</h1>
    </div>
  );
}
