export default function Leaves() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Employee Leaves</h1>
    </div>
  );
}
