import { useState } from "react";

export default function EmployeeProfile() {
  const [tab, setTab] = useState("resume");

  const tabs = ["resume", "private", "salary", "security"];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Employee Profile</h1>

      <div className="flex gap-4 border-b mb-6">
        {tabs.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`pb-2 capitalize ${
              tab === t ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-500"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="bg-white p-4 rounded shadow">
        {tab === "resume" && <p>Resume details (dummy)</p>}
        {tab === "private" && <p>Private info (dummy)</p>}
        {tab === "salary" && <p>Salary info (admin only)</p>}
        {tab === "security" && <p>Security settings</p>}
      </div>
    </div>
  );
}
