export default function Attendance() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Attendance</h1>

      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-100 text-gray-600">
            <tr>
              <th className="px-4 py-2 text-left">Employee</th>
              <th className="px-4 py-2 text-left">Check In</th>
              <th className="px-4 py-2 text-left">Check Out</th>
              <th className="px-4 py-2 text-left">Hours</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-t">
              <td className="px-4 py-2">Aarav Sharma</td>
              <td className="px-4 py-2">09:30</td>
              <td className="px-4 py-2">18:00</td>
              <td className="px-4 py-2">8.5</td>
            </tr>
            <tr className="border-t">
              <td className="px-4 py-2">Neha Verma</td>
              <td className="px-4 py-2">10:00</td>
              <td className="px-4 py-2">18:30</td>
              <td className="px-4 py-2">8.0</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
