export default function AdminDashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded shadow">
          <h2 className="font-semibold">Employees</h2>
          <p className="text-sm text-gray-500">Manage company employees</p>
        </div>

        <div className="bg-white p-4 rounded shadow">
          <h2 className="font-semibold">Attendance</h2>
          <p className="text-sm text-gray-500">View attendance records</p>
        </div>

        <div className="bg-white p-4 rounded shadow">
          <h2 className="font-semibold">Leave Requests</h2>
          <p className="text-sm text-gray-500">Approve or reject leaves</p>
        </div>
      </div>
    </div>
  );
}
