export default function AdminPayroll() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Admin Payroll</h1>
    </div>
  );
}
