export default function Approvals() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Leave Requests</h1>

      <div className="bg-white rounded shadow p-4">
        <div className="flex justify-between items-center border-b py-2">
          <div>
            <p className="font-medium">Rohit Singh</p>
            <p className="text-sm text-gray-500">Sick Leave (2 days)</p>
          </div>
          <div className="flex gap-2">
            <button className="bg-green-500 text-white px-3 py-1 rounded text-sm">
              Approve
            </button>
            <button className="bg-red-500 text-white px-3 py-1 rounded text-sm">
              Reject
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
