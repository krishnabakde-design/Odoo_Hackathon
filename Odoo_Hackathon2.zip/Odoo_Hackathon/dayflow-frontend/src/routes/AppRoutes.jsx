import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "../pages/auth/Login";
import Signup from "../pages/auth/Signup";

import Layout from "../components/Layout";

import EmployeeDashboard from "../pages/employee/Dashboard";
import Attendance from "../pages/employee/Attendance";
import Leaves from "../pages/employee/Leaves";
import Payroll from "../pages/employee/Payroll";

import AdminDashboard from "../pages/admin/Dashboard";
import Employees from "../pages/admin/Employees";
import Approvals from "../pages/admin/Approvals";
import AdminPayroll from "../pages/admin/Payroll";

import { isAuthenticated } from "../utils/auth";

function ProtectedRoute({ children }) {
  if (!isAuthenticated()) return <Navigate to="/login" />;
  return children;
}

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>

        {/* Auth routes (NO layout) */}
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* Admin routes */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="employees" element={<Employees />} />
          <Route path="approvals" element={<Approvals />} />
          <Route path="payroll" element={<AdminPayroll />} />
        </Route>

        {/* Employee routes */}
        <Route
          path="/employee"
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route path="dashboard" element={<EmployeeDashboard />} />
          <Route path="attendance" element={<Attendance />} />
          <Route path="leaves" element={<Leaves />} />
          <Route path="payroll" element={<Payroll />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/login" />} />

      </Routes>
    </BrowserRouter>
  );
}
